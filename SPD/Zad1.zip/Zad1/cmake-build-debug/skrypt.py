uchwyt = open("in10.txt")


for x in range(0,5):
    print(x)