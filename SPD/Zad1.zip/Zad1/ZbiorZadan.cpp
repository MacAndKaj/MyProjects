//
// Created by maciej on 28.02.18.
//

#include <iostream>
#include <algorithm>
#include "ZbiorZadan.h"

//****************          Konstruktory i destruktory      **************

ZbiorZadan::ZbiorZadan() {
    wek = new std::vector<Zadanie>;
    wekS = nullptr;
    wekC = nullptr;
    LElem = 0;
    licznik = 0;
}



//************************************************************************





void ZbiorZadan::sortR() {
    int liczbaelementow = this->licznik;
    do {
        for (unsigned long i = 0; i < liczbaelementow - 1; ++i) {
            if (this->wek->operator[](i).getR() > this->wek->operator[](i + 1).getR()) {
                this->zamien(i,i+1);
            }
        }
        liczbaelementow -= 1;
    } while (liczbaelementow > 1);
}


void ZbiorZadan::alg2opt() {
    this->GenerujWektory();
    int najlepsze = this->fCelu();
//    this->wypisz();


    int check=0;
    int n=this->licznik;
\\biore Cmax dla niezmienionego wektora
\\jade po calym wektorze
    for (int i = 0; i < n -1; ++i) {
        for (int j = i+1; j < n; ++j) {

            this->zamien(i, j);
            this->GenerujWektory();
            check = this->fCelu();
            if (check < najlepsze) {
                \\jesli zamiana przyniosla rezultat zostawiam ja i wracam do punktu poczatkowego
				najlepsze = check;
                i=0;
                j=i+1;
			\\jesli gorzej albo nic sie nie zmienilo to odmieniam 
            } else this->zamien(i, j);
        }
    }
//    this->wypisz();
}


int ZbiorZadan::fCelu() {
    //pusty wektor
    if (licznik == 0)return -1;
    //*****************
    int i = 0;
    int Cmax = this->wekC->operator[](i) + this->GetElementWektora(i).getQ();
    int n = this->licznik;
    int temp;
    for (i = 1; i < n; ++i) {
        temp = this->wekC->operator[](i) + this->GetElementWektora(i).getQ();
        if (temp > Cmax)
            Cmax = temp;
    }
    return Cmax;
}


\\funkcja generujaca wektory S(czas rozpoczecia) kazdego zadania
void ZbiorZadan::S() {
    int temp;

    if (this)
        this->wekS = new std::vector<int>(static_cast<unsigned long>(this->licznik));
    this->wekS->operator[](0) = this->wek->operator[](0).getR();

    for (int i = 1; i < licznik; ++i) {
        temp = this->wekS->operator[](i - 1) + this->wek->operator[](i - 1).getP();

        if (this->GetElementWektora(i).getR() > temp) {

            this->wekS->operator[](i) = this->GetElementWektora(i).getR();

        } else this->wekS->operator[](i) = temp;
    }
//    for (std::vector<int>::const_iterator j = this->wekS->begin(); j < this->wekS->end(); ++j) {
//        std::cout << j.operator*() << std::endl;
//    }
//    std::cout << std::endl;
}


\\funkcja do generowania wektorow przechowujacych C(czas zakonczenia) kazdego zadania
void ZbiorZadan::C() {
    int n = this->licznik;
    std::vector<Zadanie>::const_iterator it = this->wek->begin();
    std::vector<int>::const_iterator it2 = this->wekS->begin();

    this->wekC = new std::vector<int>(static_cast<unsigned long>(this->licznik));

    for (int i = 0; i < n; ++i) {
        wekC->operator[](i) = it.operator*().getP() + it2.operator*();
        ++it;
        ++it2;
    }

//    for (std::vector<int>::const_iterator j = this->wekC->begin(); j < this->wekC->end(); ++j) {
//        std::cout << j.operator*() << std::endl;
//    }
}
//************************************************************************************************************************

/*
 *      Getery i setery
 */

void ZbiorZadan::setLElem(int LElem) {
    ZbiorZadan::LElem = LElem;
}

int ZbiorZadan::getLElem() const {
    return LElem;
}

Zadanie &ZbiorZadan::GetElementWektora(int &indeks) const {
    return this->wek->operator[](indeks);
}

void ZbiorZadan::SetElementWektora(int &indeks, Zadanie &arg) {
    this->wek->operator[](indeks) = arg;
}


/*
 *      Dodaje zadania do zbioru
 */
void ZbiorZadan::Dodaj(Zadanie zadanko) {
    if (licznik != LElem) {
        this->wek->push_back(zadanko);
        this->licznik += 1;
    }
}


void ZbiorZadan::wypisz() {
    for (int i = 0; i < licznik; ++i) {
        std::cout << "r=" << this->wek->operator[](i).getR();
        std::cout << " p=" << this->wek->operator[](i).getP();
        std::cout << " q=" << this->wek->operator[](i).getQ() << std::endl;
    }
    std::cout << std::endl;

}

void ZbiorZadan::GenerujWektory() {
    if (this->wekS != nullptr) {
        delete this->wekC;
        delete this->wekS;
        this->wekC = nullptr;
        this->wekS = nullptr;
    }
    this->S();
    this->C();
}

void ZbiorZadan::zamien(int i, int j) {
    Zadanie temp(this->wek->operator[](i));
    this->wek->operator[](i)=this->wek->operator[](j);
    this->wek->operator[](j)=temp;
}
